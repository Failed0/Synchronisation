//package Question2;

public class Belt extends  CyclicQueue{
    /**
     * The Constructor of the circular queue
     *
     * @param capacity The size of the circular  queue
     */
    public Belt(int capacity) {
        super(capacity);
    }

    @Override
    public synchronized void enqueue(int element) throws IndexOutOfBoundsException {


        while(isFull()){
            try{
                this.wait();
            }catch (InterruptedException e){
                e.printStackTrace();
            }
        }

        super.enqueue(element);

        synchronized (this){
            this.notify();
        }



    }

    @Override
    public synchronized int dequeue() throws IndexOutOfBoundsException {

        while(isEmpty()){
            try{
                this.wait();
            }catch (InterruptedException e){
                e.printStackTrace();
            }
        }

        int number = super.dequeue();

        synchronized (this){
            this.notify();
        }

        return number;
    }
}
